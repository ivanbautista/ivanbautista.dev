//Taking in consideration that the password only uses an "@" as a simbol i decided to add it manually to the dictionary
//This is an attack based on a dictionary but modified it and added the letters from "A to Z","0 to 9","a to z", and an "@"simbol
//This atack is also based on "leetspeack", which means that uses various combinations of ASCII characters to replace Latinate letters
//This attack also toggles from lowercase to uppercase
//This attack is a dicctionary attack based and with several changes to it, it will change letters from lowercase to uppercase and leetspeack, and all of them combined

// Code from the Client.Java File
// ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓
// ↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑
// Code from the Client.Java File

import java.io.*;
import java.net.*;
import java.util.*;

// Code from the Client.Java File with some lines removed
// ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓
public class Client {
	private Socket socket;
	private PrintWriter out;
	private BufferedReader in;

	public Client() {
		try {
			socket = new Socket("localhost", 58999);
			out = new PrintWriter(socket.getOutputStream(), true);
			in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			serverRunning = true;
		} catch (Exception e) {
			System.out.print("Run the server first.\n");
			serverRunning = false;
		}
	}

	protected void finalize() {
		try {
			socket.close();
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}

	public String sendPassword(String pass) {
		if (!HUSH) {
			out.println(pass);
		}
		String result = null;
		try {
			result = in.readLine();
			if (!HUSH) {
				// this series of if statements print the last password found, and they are
				// added to an array list for their evaluatoin
				if (result.equals("yes")) {
					if (passwordsFound.size() >= 1) {
						if (passwordsFound.get(passwordsFound.size() - 1).equals(pass)) {

						} else {
							passNum++;
							passwordsFound.add(pass);
							System.out.print("A new password found" + ": "
									+ passwordsFound.get(passwordsFound.size() - 1) + "\n");
						}

					} else {
						passwordsFound.add(pass);
						System.out.print(
								"A new password found" + ": " + passwordsFound.get(passwordsFound.size() - 1) + "\n");
					}
				}
			}
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		return result;
	}

	// change this to true when running your code an extended time
	public static boolean HUSH = false;

	// ↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑
	// Code from the Client.Java File with some lines removed

	// My code
	// ↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓

	// passNum shows the password number because there are only 10 passwords and we
	// need to know at which one we are
	public static int passNum = 1;
	// array of passwords found
	public static ArrayList<String> passwordsFound = new ArrayList<String>();
	// checks if the server is running
	public static boolean serverRunning;
	// declares a new client
	public static Client me;

	public static void beginAttack() {
		Scanner sc = new Scanner(System.in);
		ArrayList<String> dictionary = new ArrayList<String>();
		String fileLocation = "./dictionaries/words.txt";
		int attackPerform = -1;
		int dictionaryAttackPerform = -1;
		int bruteForce = 0;
		int bruteForceSize = 0;
		// waits for the user ot choose an option
		while (attackPerform != 1 || attackPerform != 2 || attackPerform != 0) {
			System.out.print(
					"What type of attack do you want to perform? \n[1] Dictionary attack	[2] Brute force attack	[0] Exit\n=> ");
			try {
				attackPerform = sc.nextInt();
			} catch (Exception e) {
				sc.next();
			}
			if (attackPerform == 1 || attackPerform == 2 || attackPerform == 0) {
				break;
			}

		}
		// attack perform 1 is a dictionary attack
		if (attackPerform == 1) {
			// waits for the user ot choose an option
			while (dictionaryAttackPerform != 1 || dictionaryAttackPerform != 2 || dictionaryAttackPerform != 3
					|| dictionaryAttackPerform != 4 || dictionaryAttackPerform != 0) {
				System.out.print(
						"Which dictionary attack do you want to perform?\n[1] Only dictionary attack	[2] Lowercase & Uppercase	[3] Replace letters with numbers or @ sign	[4] All of the above	[0] Exit\n=> ");
				try {
					dictionaryAttackPerform = sc.nextInt();
				} catch (Exception e) {
					sc.next();
				}
				if (dictionaryAttackPerform == 1 || dictionaryAttackPerform == 2 || dictionaryAttackPerform == 3
						|| dictionaryAttackPerform == 4 || dictionaryAttackPerform == 0) {
					break;
				}
			}
			// loads the dictionay in an arraylist because this attack mode "1" is a
			// dictionary attack
			// tries to load the dictionary into an arraylist
			try {
				Scanner inputFile = new Scanner(new File(fileLocation));
				while (inputFile.hasNextLine()) {
					dictionary.add(inputFile.nextLine());
				}
				inputFile.close();
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
			// dictionary atack "1" is only the dictionary without changes
			// this if statement sends all the dictionary to the sever
			if (dictionaryAttackPerform == 1) {
				for (int i = 0; i < dictionary.size(); i++) {
					me.sendPassword(dictionary.get(i));
				}
			} else if (dictionaryAttackPerform == 2) {
				// sends the dictionary word by word to caseMixDictionary to swap lowercase and
				// uppercase in all the possible ways
				for (int i = 0; i < dictionary.size(); i++) {
					// for each word there should be several ways so
					// "dictionaryLowercaseUppercase"is an array wiht all multiple ways
					// ready to be sended by me.sendpassword.
					ArrayList<String> dictionaryLowercaseUppercase = caseMixDictionary(dictionary.get(i));
					for (int j = 0; j < (dictionaryLowercaseUppercase).size(); j++) {
						me.sendPassword((dictionaryLowercaseUppercase).get(j));
					}
				}
			} else if (dictionaryAttackPerform == 3) {
				// sends the dictionary to leetspek word by word to replace some chars.
				for (int i = 0; i < dictionary.size(); i++) {
					// this for cicle sends a word to leetspeak to replace one char per word like a
					// to @
					ArrayList<String> dictionaryLeetspeak = leetspeak(dictionary.get(i));
					for (int j = 0; j < (dictionaryLeetspeak).size(); j++) {
						me.sendPassword((dictionaryLeetspeak).get(j));
						// this for cicle sends the array received from the leetspeak to replace one
						// char per word, so in total there should be 2 different chars changed that
						// will be sent like a-@ in all occurrencies and o-0 in all occurencies too
						ArrayList<String> dictionaryLeetspeak2 = leetspeak((dictionaryLeetspeak).get(j));
						for (int j2 = 0; j2 < (dictionaryLeetspeak2).size(); j2++) {
							me.sendPassword((dictionaryLeetspeak2).get(j2));
						}
					}
				}
			} else if (dictionaryAttackPerform == 4) {
				// sends the dictionary word by word to caseMixDictionary to swap lowercase and
				// uppercase in all the possible ways
				for (int i = 0; i < dictionary.size(); i++) {
					// for each word there should be several ways so
					// "dictionaryLowercaseUppercase"is an array wiht all multiple ways
					// ready to be sended by me.sendpassword.
					ArrayList<String> dictionaryLowercaseUppercase = caseMixDictionary(dictionary.get(i));
					for (int k = 0; k < (dictionaryLowercaseUppercase).size(); k++) {
						me.sendPassword((dictionaryLowercaseUppercase).get(k));
						// this for cicle sends a word to leetspeak to replace one char per word like a
						// to @
						ArrayList<String> dictionaryLeetspeak = leetspeak((dictionaryLowercaseUppercase).get(k));
						for (int j = 0; j < (dictionaryLeetspeak).size(); j++) {
							me.sendPassword((dictionaryLeetspeak).get(j));
							// this for cicle sends the array received from the leetspeak to replace one
							// char per word, so in total there should be 2 different chars changed that
							// will be sent like a-@ in all occurrencies and o-0 in all occurencies too
							ArrayList<String> dictionaryLeetspeak2 = leetspeak((dictionaryLeetspeak).get(j));
							for (int j2 = 0; j2 < (dictionaryLeetspeak2).size(); j2++) {
								me.sendPassword((dictionaryLeetspeak2).get(j2));
							}
						}
					}
				}
			}
		} else if (attackPerform == 2) {
			// waits for the user to choose an option
			while (bruteForce != 1 || bruteForce != 2 || bruteForce != 3 || bruteForce != 0) {
				System.out.print(
						"Which Brute Force attack do you want to perform?\n[1] Only letters and @	[2] Only numbers	[3] All of the above	[0] Exit\n=> ");
				try {
					bruteForce = sc.nextInt();
				} catch (Exception e) {
					sc.next();
				}
				if (bruteForce == 1 || bruteForce == 2 || bruteForce == 3 || bruteForce == 0) {
					break;
				}
			}
			if (bruteForce == 1) {
				// begins a brute force attack of a certain lenght with the characters specified
				// in the string possible characters
				System.out.print("Enter the lenght of your attack\n=> ");
				String possiblecharacters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz@";
				bruteForceSize = sc.nextInt();
				generate(possiblecharacters, "", bruteForceSize);
			} else if (bruteForce == 2) {
				// begins a brute force attack of a certain lenght with the characters specified
				// in the string possible characters
				System.out.print("Enter the lenght of your attack\n=> ");
				String possiblecharacters = "1234567890";
				bruteForceSize = sc.nextInt();
				generate(possiblecharacters, "", bruteForceSize);
			} else if (bruteForce == 3) {
				// begins a brute force attack of a certain lenght with the characters specified
				// in the string possible characters

				System.out.print("Enter the lenght of your attack\n=> ");
				String possiblecharacters = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz@123456789";
				bruteForceSize = sc.nextInt();
				generate(possiblecharacters, "", bruteForceSize);
			}

		}
		boolean paswrodExists = false;
		ArrayList<Integer> passwordsNotRecovered = new ArrayList<Integer>();

		String passworRecovered = "";
		// the next lines is only to give format to the output of the passwords
		// recovered
		System.out.println("\n====================== Paswords Recovered ======================\n");
		for (int i = 1; i <= 10; i++) {
			paswrodExists = false;
			for (int k = 0; k < passwordsFound.size(); k++) {
				if (passwordsFound.get(k).length() == (i)) {
					passworRecovered = ("=> Password Number " + (i) + ": " + passwordsFound.get(k));
					paswrodExists = true;
					k = 100;
				} else {
					paswrodExists = false;
				}
			}
			if (paswrodExists == true) {
				System.out.println(passworRecovered);
			} else {
				System.out.println("=> Password Number " + (i) + ": It was not found!");
				passwordsNotRecovered.add(i);
			}
		}
		int anotherAttack = 0;
		if (passwordsNotRecovered.size() > 0) {
			System.out.print("\nPasswords with the following length were not found " + passwordsNotRecovered + ".");

			while (anotherAttack != 1 || anotherAttack != 2) {
				System.out.print(" Do you want to try another attack? \n[1] No	[2] Yes	\n=> ");
				try {
					anotherAttack = sc.nextInt();
				} catch (Exception e) {
					sc.next();
				}
				if (anotherAttack == 1 || anotherAttack == 2) {
					break;
				}

			}

			if (anotherAttack == 2) {
				beginAttack();
			}
		} else {
			System.out.println("\nWe found all the passwords!!\n");
		}

	}

	public static void main(String[] args) {

		// begins an instance of Client()
		me = new Client();

		// checks if the server is running, if not it'll stop the program
		if (serverRunning == true) {
			beginAttack();
		}

	}

	// mix letters lowerchase & uppercase from the dictionary
	private static ArrayList<String> caseMixDictionary(String word) {
		ArrayList<String> wordCaseCombined = new ArrayList<String>();
		String wordMixed = "";
		// this is the lenght of the word
		int wordSize = word.length();
		int uppercase = 0;
		int lowercase = 0;
		// int max is the number of posibilities of the change of the case of the
		// string. the number 2 means that each character chan change only 2 times 1
		// lowecase and another uppercase, so for example we have a string of lengh 2,
		// this 2 to the 2 would produce 4 results, like if we have the word "of" the
		// posibilities would be [of, Of,oF,OF]
		int max = ((int) (Math.pow(2, wordSize)));
		// this makes sure that all the words is lowercase, just to save time and lines
		// of code
		word = word.toLowerCase();
		// this is the current word that we are working with
		String currentword;
		// this for loop sends copies of the word ot be processed because we will change
		// one by one and we wont need to change to lowercase,
		for (int i = 0; i < max; i++) {
			wordCaseCombined.add(word);
		}
		// we are going to change the word by word the first,,, to the n position one by
		// one in all the array, then to the 2 positoin of the word
		for (int i = 0; i < wordSize; i++) {
			// case secuence, I found this the most easyest way to change the case of a
			// word, like for example we have a word of lenght 3 like "for", we know that we
			// will have 8 possible passwords from here, and the possible differente answers
			// will be like [for, For, fOr, FOr, foR, FoR, fOR, FOR, ] and I found that the
			// first character changes every 2^0 =(1) in other words, the letter f changes
			// from uppercase to lowercase in the secuence of one by one, this is the same
			// case with the letter at positoin 2 it changes at 2^1=(2) so 2 letters are
			// uppercase and the other 2 letters are lowercase, so there will be a char
			// sequence change at 2 to the power of the char positoin
			int caseSecuence = ((int) (Math.pow(2, i)));
			// this passess all the array to be changed as previously specified
			for (int j = 0; j < max; j++) {
				// this declares the current word
				currentword = wordCaseCombined.get(j);

				StringBuilder myString = new StringBuilder(currentword);
				// lowercase is here because it needs to regulate that the chars lowercase wont
				// be modified to uppercase
				lowercase++;
				// this if statement changes the secuence of characters
				if (uppercase < caseSecuence && lowercase > caseSecuence) {
					uppercase++;
					// this changes the character that needs to be changed
					myString.setCharAt(i, Character.toUpperCase(currentword.charAt(i)));
					// changes the word in the array for the word modified
					wordCaseCombined.set(j, myString.toString());
					// resets the sequence
					if ((uppercase) >= caseSecuence) {
						lowercase = 0;
						uppercase = 0;
					}
				}
			}
		}

		// // the for loop is the regulator for all the possible combinations
		// for (int i = 0; i < max; i++) {
		// // comberts the word into an array of chars
		// char combination[] = word.toCharArray();

		// for (int j = 0; j < wordSize; j++) {
		// // 8>>3 this makes for example the number "8" to binary would be (1000) and
		// that
		// // operator makes the reverse than the previous one of the if statement so it
		// // would move the first number to 3 3rd position to the right so the value
		// would
		// // be(0001) or in decimal "1"
		// // then the operator & compares which value is the smaller one,
		// if (((i >> j) & 1) == 1)
		// combination[j] = Character.toUpperCase(combination[j]);
		// }
		// // wordmixed is the combination of uppercase and lowercase
		// wordMixed = new String(combination);
		// wordCaseCombined.add(wordMixed);

		// }
		return wordCaseCombined;
	}

	// will return an array with leetspeak characters modified
	private static ArrayList<String> leetspeak(String word) {
		ArrayList<String> leetspekCombined = new ArrayList<String>();

		// will replace letters with other characters like leetspeak
		leetspekCombined.add(word.replaceAll("a", "@"));
		leetspekCombined.add(word.replaceAll("e", "3"));
		leetspekCombined.add(word.replaceAll("o", "0"));
		leetspekCombined.add(word.replaceAll("l", "1"));
		leetspekCombined.add(word.replaceAll("i", "1"));
		leetspekCombined.add(word.replaceAll("s", "5"));
		leetspekCombined.add(word.replaceAll("z", "2"));

		leetspekCombined.add(word.replaceAll("A", "@"));
		leetspekCombined.add(word.replaceAll("E", "3"));
		leetspekCombined.add(word.replaceAll("O", "0"));
		leetspekCombined.add(word.replaceAll("L", "1"));
		leetspekCombined.add(word.replaceAll("I", "1"));
		leetspekCombined.add(word.replaceAll("S", "5"));
		leetspekCombined.add(word.replaceAll("Z", "2"));
		// will return an array wit the word changed if it has those characters
		return leetspekCombined;
	}

	// will mix the characters until get the desired size
	public static void tryAll(int counter, String password, int length, String characters) {
		// it will check if the counter of the desired size,
		if (counter < characters.length()) {
			// it will generate a new password of recursivelly
			generate(characters, password + characters.charAt(counter), length);
			// this one will send the counter to tryall to check if it is of the desired
			// length
			tryAll(counter + 1, password, length, characters);

		}
	}

	// this one will generate a password with the parameters specified
	public static void generate(String characters, String password, int length) {
		// will chech if it is not the appropriate lenght, and if it is it will send the
		// password
		if (password.length() < length) {
			// will send the current password to get a new one
			tryAll(0, password, length, characters);
		} else {// password is long enough (base case)
			// this will send the password to the server
			me.sendPassword(password);
			// this if statement will brake the recursion, so it'll stop when the password
			// is obtaned
			if (passNum > 0) {

				length--;
			}

		}
	}
}