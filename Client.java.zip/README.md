# Password recovery tool

The dictionary that I used for my dictionary attack I found it in
[english-words](https://github.com/dwyl/english-words)

## How to use this tool

The use of this tool it's straight forward just follow the instructions and that's it. It requires the server to be running before begining any attack.
